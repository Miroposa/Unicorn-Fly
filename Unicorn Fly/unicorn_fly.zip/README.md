# Unicorn Fly 🦄

Ein magisches Flappy-Bird-Spiel mit Einhorn-Theme, entwickelt in reinem HTML5 Canvas und JavaScript.

## 🎮 Spielbeschreibung

**Unicorn Fly** ist ein Endless-Runner-Spiel, bei dem du ein fliegendes Einhorn durch eine magische Wolkenlandschaft steuerst. Sammle Sterne, vermeide Wolken und versuche so weit wie möglich zu kommen!

### ✨ Features

- **Magisches Einhorn-Theme** mit schönen Grafiken und Animationen
- **Sterne sammeln** für Punkte (3 Sterne pro Wolkenlücke)
- **Schwierigkeitssteigerung** - das Spiel wird alle 30 Punkte schneller
- **Partikel-Effekte** beim Fliegen mit Sternenstaub
- **Responsive Design** für Desktop und Mobile
- **HiDPI-Unterstützung** für scharfe Darstellung auf Retina-Displays
- **Hintergrundmusik** und Soundeffekte
- **Highscore-System** mit lokaler Speicherung

### 🎯 Spielmechanik

- **Ziel:** Sammle so viele Sterne wie möglich, ohne die Wolken zu berühren
- **Steuerung:** Einfach klicken/tappen oder Leertaste drücken zum Fliegen
- **Kollision:** Berühre keine Wolken oder den Boden
- **Punkte:** Jeder gesammelte Stern gibt 1 Punkt
- **Schwierigkeit:** Alle 30 Punkte wird das Spiel schneller

## 🚀 Start

1. Öffne die Datei `index.html` im Browser (Doppelklick)
2. Klicke auf "Play" oder drücke Enter/Leertaste zum Starten
3. Viel Spaß beim Spielen!

## 🎮 Steuerung

- **Fliegen:** Leertaste, Pfeil nach oben, oder Klick/Touch
- **Pause:** P-Taste oder Pause-Button
- **Neustart:** Enter, Leertaste oder Klick nach Game Over
- **Spiel starten:** Enter oder Play-Button

## 📱 Technische Details

- **Auflösung:** 400x600 Pixel (Canvas)
- **HiDPI-Skalierung:** Automatische Anpassung an Bildschirmauflösung
- **Mobile Optimierung:** Responsive Design für verschiedene Bildschirmgrößen
- **Audio:** WebAudio API mit HTML5 Audio Fallback
- **Speicherung:** Highscore wird im Browser-LocalStorage gespeichert

## 🎨 Assets

Das Spiel verwendet verschiedene Grafiken und Sounds:
- Einhorn-Sprite für den Spieler
- Wolken-Sprites für Hindernisse
- Stern-Sprites für Sammelobjekte
- Hintergrundbilder mit Parallax-Effekt
- Soundeffekte und Hintergrundmusik

## 🛠️ Entwicklung

- **Technologie:** Vanilla JavaScript, HTML5 Canvas, CSS3
- **Keine Abhängigkeiten:** Läuft ohne externe Bibliotheken
- **Browser-Kompatibilität:** Moderne Browser mit Canvas-Unterstützung


